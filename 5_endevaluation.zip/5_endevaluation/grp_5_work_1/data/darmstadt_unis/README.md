# How to preprocess the data

 First download the darmstadt data from the following url (<https://tudatalib.ulb.tu-darmstadt.de/handle/tudatalib/2448>) and put the zip file in this directory.

Then run the process_darmstadt.sh script from the command line:

```
bash preprocess_darmstadt.sh
```

If you are running OSX, use this command instead:

```
bash preprocess_darmstadt_OSX.sh
```
